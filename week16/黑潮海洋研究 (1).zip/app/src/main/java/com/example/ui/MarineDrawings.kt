package com.example.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.Fill
import androidx.compose.ui.graphics.drawscope.drawIntoCanvas
import androidx.compose.ui.unit.dp
import com.example.data.TrackPoint
import kotlin.math.cos
import kotlin.math.sin

/**
 * 繪製海巨型生物的幾何向量圖示 (鲸鯊, 綠蠵龜, 大翅鯨)
 */
@Composable
fun MarineCreatureVector(
    type: String,
    modifier: Modifier = Modifier,
    color: Color = Color(0xFF00F0FF)
) {
    val infiniteTransition = rememberInfiniteTransition(label = "creature_anim")
    val swimOffset by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(1200, easing = EaseInOutSine),
            repeatMode = RepeatMode.Reverse
        ),
        label = "swim"
    )

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height
        val cx = w / 2f
        val cy = h / 2f + swimOffset

        when (type) {
            "shark", "shark_whale" -> {
                // 鯨鯊與鯊魚向量圖案
                val bodyPath = Path().apply {
                    moveTo(cx - w * 0.4f, cy)
                    quadraticTo(cx - w * 0.1f, cy - h * 0.25f, cx + w * 0.35f, cy - h * 0.05f) // 背部
                    // 尾鰭
                    lineTo(cx + w * 0.45f, cy - h * 0.3f)
                    lineTo(cx + w * 0.4f, cy)
                    lineTo(cx + w * 0.45f, cy + h * 0.3f)
                    lineTo(cx + w * 0.25f, cy + h * 0.08f)
                    // 腹部
                    quadraticTo(cx - w * 0.1f, cy + h * 0.20f, cx - w * 0.4f, cy)
                    close()
                }
                
                // 胸鰭
                val finPath = Path().apply {
                    moveTo(cx - w * 0.1f, cy + h * 0.05f)
                    lineTo(cx - w * 0.25f, cy + h * 0.35f)
                    lineTo(cx - w * 0.05f, cy + h * 0.12f)
                    close()
                }

                // 背鰭
                val backFin = Path().apply {
                    moveTo(cx + w * 0.05f, cy - h * 0.13f)
                    lineTo(cx + w * 0.12f, cy - h * 0.35f)
                    lineTo(cx + w * 0.20f, cy - h * 0.07f)
                    close()
                }

                drawPath(bodyPath, color, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
                drawPath(finPath, color, style = Stroke(width = 3f, cap = StrokeCap.Round))
                drawPath(backFin, color, style = Stroke(width = 3f, cap = StrokeCap.Round))

                // 點綴著名的斑點 (鯨鯊特徵)
                if (type == "shark_whale") {
                    drawCircle(color, 2f, Offset(cx - w * 0.15f, cy - h * 0.02f))
                    drawCircle(color, 2f, Offset(cx - w * 0.1f, cy - h * 0.03f))
                    drawCircle(color, 2f, Offset(cx - w * 0.05f, cy - h * 0.01f))
                    drawCircle(color, 2f, Offset(cx, cy - h * 0.02f))
                    drawCircle(color, 2f, Offset(cx + w * 0.08f, cy))
                    drawCircle(color, 1.5f, Offset(cx + w * 0.15f, cy + h * 0.01f))
                }
            }

            "turtle" -> {
                // 綠蠵龜向量圖案
                val shellPath = Path().apply {
                    addOval(androidx.compose.ui.geometry.Rect(cx - w * 0.25f, cy - h * 0.2f, cx + w * 0.25f, cy + h * 0.25f))
                }
                // 頭部
                val headPath = Path().apply {
                    addOval(androidx.compose.ui.geometry.Rect(cx - w * 0.08f, cy - h * 0.38f, cx + w * 0.08f, cy - h * 0.18f))
                }
                // 前肢 (左右鰭足)
                val leftFin = Path().apply {
                    moveTo(cx - w * 0.15f, cy - h * 0.05f)
                    quadraticTo(cx - w * 0.45f, cy - h * 0.15f, cx - w * 0.42f, cy - h * 0.32f)
                    quadraticTo(cx - w * 0.22f, cy - h * 0.15f, cx - w * 0.15f, cy - h * 0.05f)
                    close()
                }
                val rightFin = Path().apply {
                    moveTo(cx + w * 0.15f, cy - h * 0.05f)
                    quadraticTo(cx + w * 0.45f, cy - h * 0.15f, cx + w * 0.42f, cy - h * 0.32f)
                    quadraticTo(cx + w * 0.22f, cy - h * 0.15f, cx + w * 0.15f, cy - h * 0.05f)
                    close()
                }
                // 後肢
                val rearLeft = Path().apply {
                    moveTo(cx - w * 0.12f, cy + h * 0.18f)
                    lineTo(cx - w * 0.25f, cy + h * 0.35f)
                    lineTo(cx - w * 0.08f, cy + h * 0.23f)
                    close()
                }
                val rearRight = Path().apply {
                    moveTo(cx + w * 0.12f, cy + h * 0.18f)
                    lineTo(cx + w * 0.25f, cy + h * 0.35f)
                    lineTo(cx + w * 0.08f, cy + h * 0.23f)
                    close()
                }

                drawPath(shellPath, color, style = Stroke(width = 3.5f))
                drawPath(headPath, color, style = Stroke(width = 3f))
                drawPath(leftFin, color, style = Stroke(width = 3f))
                drawPath(rightFin, color, style = Stroke(width = 3f))
                drawPath(rearLeft, color, style = Stroke(width = 3f))
                drawPath(rearRight, color, style = Stroke(width = 3f))

                // 龜殼龜裂紋路
                drawLine(color, Offset(cx, cy - h * 0.2f), Offset(cx, cy + h * 0.25f), strokeWidth = 2f)
                drawLine(color, Offset(cx - w * 0.25f, cy), Offset(cx + w * 0.25f, cy), strokeWidth = 2f)
            }

            "manta" -> {
                // 鬼蝠魟向量圖案
                val wingPath = Path().apply {
                    moveTo(cx, cy + h * 0.3f) // 尾端
                    quadraticTo(cx - w * 0.12f, cy + h * 0.10f, cx - w * 0.48f, cy - h * 0.08f) // 左翼下緣
                    lineTo(cx - w * 0.15f, cy - h * 0.18f) // 左翼前緣
                    // 頭角
                    lineTo(cx - w * 0.08f, cy - h * 0.35f)
                    lineTo(cx - w * 0.04f, cy - h * 0.22f)
                    lineTo(cx + w * 0.04f, cy - h * 0.22f)
                    lineTo(cx + w * 0.08f, cy - h * 0.35f)
                    // 右翼
                    lineTo(cx + w * 0.15f, cy - h * 0.18f)
                    lineTo(cx + w * 0.48f, cy - h * 0.08f) // 右翼前緣下行
                    quadraticTo(cx + w * 0.12f, cy + h * 0.10f, cx, cy + h * 0.3f)
                    close()
                }
                
                // 尾鞭
                val tailPath = Path().apply {
                    moveTo(cx, cy + h * 0.3f)
                    quadraticTo(cx + w * 0.05f, cy + h * 0.42f, cx - w * 0.02f, cy + h * 0.55f)
                }

                drawPath(wingPath, color, style = Stroke(width = 3.5f))
                drawPath(tailPath, color, style = Stroke(width = 2.5f))
            }
            
            "sawfish" -> {
                // 波口鱟頭鱝
                val bodyPath = Path().apply {
                    moveTo(cx - w * 0.4f, cy)
                    quadraticTo(cx - w * 0.1f, cy - h * 0.32f, cx + w * 0.4f, cy)
                    quadraticTo(cx - w * 0.1f, cy + h * 0.32f, cx - w * 0.4f, cy)
                    close()
                }
                val tail = Path().apply {
                    moveTo(cx + w * 0.2f, cy)
                    lineTo(cx + w * 0.48f, cy - h * 0.15f)
                    lineTo(cx + w * 0.4f, cy)
                    lineTo(cx + w * 0.48f, cy + h * 0.15f)
                    close()
                }
                drawPath(bodyPath, color, style = Stroke(width = 3.5f))
                drawPath(tail, color, style = Stroke(width = 3f))
            }

            else -> {
                // 預設是大翅鯨/鯨魚
                val whalePath = Path().apply {
                    moveTo(cx - w * 0.45f, cy + h * 0.05f) // 鳥嘴/額頭
                    quadraticTo(cx - w * 0.2f, cy - h * 0.30f, cx + w * 0.15f, cy - h * 0.02f) // 寬背
                    lineTo(cx + w * 0.38f, cy - h * 0.15f) // 尾柄
                    lineTo(cx + w * 0.48f, cy - h * 0.28f) // 尾鰭上
                    lineTo(cx + w * 0.42f, cy)             // 尾鰭中
                    lineTo(cx + w * 0.48f, cy + h * 0.28f) // 尾鰭下
                    lineTo(cx + w * 0.32f, cy + h * 0.08f) // 尾柄下
                    quadraticTo(cx - w * 0.15f, cy + h * 0.40f, cx - w * 0.45f, cy + h * 0.05f) // 下腹
                    close()
                }

                // 長長胸鰭
                val whaleFin = Path().apply {
                    moveTo(cx - w * 0.1f, cy + h * 0.12f)
                    quadraticTo(cx - w * 0.25f, cy + h * 0.45f, cx - w * 0.3f, cy + h * 0.42f)
                    quadraticTo(cx - w * 0.15f, cy + h * 0.22f, cx - w * 0.1f, cy + h * 0.12f)
                    close()
                }

                drawPath(whalePath, color, style = Stroke(width = 3.5f, cap = StrokeCap.Round))
                drawPath(whaleFin, color, style = Stroke(width = 3f, cap = StrokeCap.Round))
            }
        }
    }
}

/**
 * 黑潮衛星追蹤專用：高科技模擬雷達地圖
 * 以 Canvas 精美描繪台灣與周緣黑潮，並繪製主動追蹤航跡點與動態游動效果。
 */
@Composable
fun KuroshioTelemetryMap(
    points: List<TrackPoint>,
    currentIndex: Int,
    isSimulating: Boolean,
    modifier: Modifier = Modifier,
    onPointSelected: (Int) -> Unit = {}
) {
    // 取得黑潮流動相位動畫
    val infiniteTransition = rememberInfiniteTransition(label = "kuroshio_map_flow")
    val flowPhase by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 200f,
        animationSpec = infiniteRepeatable(
            animation = tween(4000, easing = LinearEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "phase"
    )

    // 動態雷達訊號擴散環
    val pingRadius by infiniteTransition.animateFloat(
        initialValue = 4f,
        targetValue = 32f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseOutQuad),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_ring"
    )
    val pingAlpha by infiniteTransition.animateFloat(
        initialValue = 0.8f,
        targetValue = 0f,
        animationSpec = infiniteRepeatable(
            animation = tween(1500, easing = EaseOutQuad),
            repeatMode = RepeatMode.Restart
        ),
        label = "radar_alpha"
    )

    // 經緯對應地圖畫布座標常數
    // 台灣地圖覆蓋範疇：緯度 20.0°N ~ 26.5°N，經度 119.5°E ~ 123.5°E
    val minLat = 20.0
    val maxLat = 26.5
    val minLng = 119.5
    val maxLng = 123.5

    Canvas(modifier = modifier) {
        val w = size.width
        val h = size.height

        // 經緯度映射為 XY 座標之 inline function
        fun getOffset(latitude: Double, longitude: Double): Offset {
            val pctX = (longitude - minLng) / (maxLng - minLng)
            // 緯度越高，畫面 Y 軸坐標越小
            val pctY = 1.0 - (latitude - minLat) / (maxLat - minLat)
            return Offset((pctX * w).toFloat(), (pctY * h).toFloat())
        }

        // 1. 繪製精緻的網格經緯網 (高科技機艙雷達感)
        val gridColor = Color(0xFF1B4965).copy(alpha = 0.35f)
        val stepX = w / 8f
        val stepY = h / 8f
        for (i in 0..8) {
            drawLine(gridColor, Offset(i * stepX, 0f), Offset(i * stepX, h), strokeWidth = 1f)
            drawLine(gridColor, Offset(0f, i * stepY), Offset(w, i * stepY), strokeWidth = 1f)
        }

        // 2. 綠色虛線繪出 - 黑潮主要流軸帶 (雙通道流體效果)
        val kuroshioColor = Color(0xFF00FFCC).copy(alpha = 0.22f)
        val kuroshioStroke = Stroke(width = 46.dp.toPx(), cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(50f, 40f), flowPhase))
        val currentPath = Path().apply {
            // 巴士海峽流進外洋
            moveTo(w * 0.48f, h * 0.95f)
            // 經過蘭嶼
            quadraticTo(w * 0.65f, h * 0.75f, w * 0.62f, h * 0.60f)
            // 花蓮大斜坡加急
            cubicTo(w * 0.62f, h * 0.45f, w * 0.72f, h * 0.35f, w * 0.88f, h * 0.20f)
        }
        drawPath(currentPath, kuroshioColor, style = kuroshioStroke)

        // 繪製黑潮深藍核心流軸
        val coreKuroshioColor = Color(0xFF00B4D8).copy(alpha = 0.35f)
        val coreKuroshioStroke = Stroke(width = 18.dp.toPx(), cap = StrokeCap.Round, pathEffect = PathEffect.dashPathEffect(floatArrayOf(30f, 30f), flowPhase * 1.5f))
        drawPath(currentPath, coreKuroshioColor, style = coreKuroshioStroke)

        // 3. 繪製台灣島廓輪廓
        // 利用數學頂點，畫出精美的發光多邊形
        val twVertices = listOf(
            Offset(0.38f, 0.25f), // 最北端 富貴角
            Offset(0.48f, 0.30f), // 东北角 三貂角
            Offset(0.46f, 0.42f), // 立霧溪口 (花蓮北)
            Offset(0.41f, 0.58f), // 秀姑巒溪口 (花蓮南)
            Offset(0.36f, 0.74f), // 台東
            Offset(0.31f, 0.84f), // 恆春半島/鵝鑾鼻
            Offset(0.24f, 0.75f), // 高雄貓鼻頭邊緣
            Offset(0.21f, 0.65f), // 鯤鯓海岸 (台南)
            Offset(0.18f, 0.55f), // 濁水溪口 (彰化/雲林)
            Offset(0.22f, 0.45f), // 后里海岸 (台中/苗栗)
            Offset(0.28f, 0.35f)  // 桃竹海岸
        )
        
        val landPath = Path().apply {
            moveTo(twVertices[0].x * w, twVertices[0].y * h)
            for (i in 1 until twVertices.size) {
                lineTo(twVertices[i].x * w, twVertices[i].y * h)
            }
            close()
        }

        // 以半透明深色填充陸地 + 霓虹草綠色勾邊
        drawPath(landPath, brush = Brush.linearGradient(listOf(Color(0xFF0F2027), Color(0xFF203A43))), style = Fill)
        drawPath(landPath, color = Color(0xFF00FFCC).copy(alpha = 0.55f), style = Stroke(width = 2.5f))

        // 點綴中央山脈山脊微弱骨幹線
        val mountainPath = Path().apply {
            moveTo(0.34f * w, 0.30f * h)
            lineTo(0.36f * w, 0.48f * h)
            lineTo(0.31f * w, 0.68f * h)
            lineTo(0.29f * w, 0.78f * h)
        }
        drawPath(mountainPath, Color(0xFF48CAE4).copy(alpha = 0.25f), style = Stroke(width = 2f))

        // 標註各大城市和離島小發光塊
        // 綠島
        drawCircle(Color(0xFF00FFCC), 4f, Offset(0.39f * w, 0.70f * h))
        // 蘭嶼
        drawCircle(Color(0xFF00FFCC), 5f, Offset(0.42f * w, 0.76f * h))
        // 小琉球
        drawCircle(Color(0xFF00FFCC), 3.5f, Offset(0.20f * w, 0.78f * h))
        // 澎湖群島
        drawCircle(Color(0xFFE0E0E0), 3f, Offset(0.10f * w, 0.52f * h))
        drawCircle(Color(0xFFE0E0E0), 2f, Offset(0.09f * w, 0.54f * h))

        // 4. 繪製衛星追蹤航線
        if (points.isNotEmpty()) {
            val trackPath = Path()
            val drawPoints = points.map { getOffset(it.latitude, it.longitude) }

            trackPath.moveTo(drawPoints.first().x, drawPoints.first().y)
            for (i in 1 until drawPoints.size) {
                trackPath.lineTo(drawPoints[i].x, drawPoints[i].y)
            }

            // 繪製閃耀的科技線條 (未到點是虛線，已到點是實線)
            drawPath(
                trackPath,
                color = Color(0xFFFF9F43).copy(alpha = 0.75f),
                style = Stroke(width = 3f, cap = StrokeCap.Round)
            )

            // 實心绘制所有軌跡歷史節點
            for (i in drawPoints.indices) {
                val isCurrent = i == currentIndex
                val pt = drawPoints[i]
                
                if (isCurrent) {
                    // 當前播放點，繪製高科技雷達雷電信號擴散圈
                    drawCircle(
                        color = Color(0xFFFF4D4D).copy(alpha = pingAlpha),
                        radius = pingRadius,
                        center = pt,
                        style = Stroke(width = 1.5.dp.toPx())
                    )
                    drawCircle(
                        color = Color(0xFFFF4D4D),
                        radius = 6.5f,
                        center = pt
                    )
                    drawCircle(
                        color = Color.White,
                        radius = 2.5f,
                        center = pt
                    )
                } else {
                    // 一般歷史採樣點
                    val isVisited = i < currentIndex
                    val dotColor = if (isVisited) Color(0xFFFECA57) else Color(0xFFFECA57).copy(alpha = 0.35f)
                    val dotSize = if (isVisited) 4.5f else 3.5f
                    
                    drawCircle(
                        color = dotColor,
                        radius = dotSize,
                        center = pt
                    )
                }
            }
        }
    }
}
