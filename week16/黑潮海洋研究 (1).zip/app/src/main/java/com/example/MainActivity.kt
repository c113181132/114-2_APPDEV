package com.example

import android.os.Bundle
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.animation.*
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material.icons.outlined.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.geometry.CornerRadius
import com.example.data.*
import com.example.ui.*
import com.example.ui.theme.*
import com.example.viewmodel.MarineViewModel
import com.example.viewmodel.MarineViewModelFactory
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MyApplicationTheme(darkTheme = true) { // 預設高科技暗色沉浸式海洋控制台
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    // 初始化 SQLite Room 本地資料庫與 repository
                    val context = LocalContext.current
                    val database = remember { AppDatabase.getDatabase(context) }
                    val repository = remember { MarineRepository(database.reportDao()) }
                    
                    // 使用 Factory 注入 ViewModel
                    val marineViewModel: MarineViewModel = viewModel(
                        factory = MarineViewModelFactory(repository)
                    )

                    MarineMainScaffold(viewModel = marineViewModel)
                }
            }
        }
    }
}

@Composable
fun MarineMainScaffold(viewModel: MarineViewModel) {
    val activeTab by viewModel.activeTab.collectAsStateWithLifecycle()

    BoxWithConstraints(modifier = Modifier.fillMaxSize()) {
        val isWide = maxWidth > 600.dp

        Scaffold(
            bottomBar = {
                if (!isWide) {
                    MarineBottomNavigation(
                        activeTab = activeTab,
                        onTabSelected = { viewModel.selectTab(it) }
                    )
                }
            },
            contentWindowInsets = WindowInsets.safeDrawing
        ) { innerPadding ->
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding)
            ) {
                if (isWide) {
                    MarineNavigationRail(
                        activeTab = activeTab,
                        onTabSelected = { viewModel.selectTab(it) }
                    )
                    VerticalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                }

                Box(modifier = Modifier.fillMaxSize()) {
                    when (activeTab) {
                        0 -> DashboardScreen(viewModel = viewModel)
                        1 -> DigitalGuideScreen(viewModel = viewModel)
                        2 -> SatelliteTrackingScreen(viewModel = viewModel)
                        3 -> CitizenScienceScreen(viewModel = viewModel)
                    }
                }
            }
        }
    }
}

// --- 導覽列組件 (支援響應式適配) ---
@Composable
fun MarineBottomNavigation(
    activeTab: Int,
    onTabSelected: (Int) -> Unit
) {
    NavigationBar(
        modifier = Modifier.testTag("bottom_nav_bar"),
        containerColor = MaterialTheme.colorScheme.surface,
        tonalElevation = 8.dp
    ) {
        NavigationBarItem(
            selected = activeTab == 0,
            onClick = { onTabSelected(0) },
            icon = { Icon(if (activeTab == 0) Icons.Filled.Dashboard else Icons.Outlined.Dashboard, contentDescription = "主儀表") },
            label = { Text("控制中心", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            )
        )
        NavigationBarItem(
            selected = activeTab == 1,
            onClick = { onTabSelected(1) },
            icon = { Icon(if (activeTab == 1) Icons.Filled.MenuBook else Icons.Outlined.MenuBook, contentDescription = "圖鑑") },
            label = { Text("軟骨魚圖鑑", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            )
        )
        NavigationBarItem(
            selected = activeTab == 2,
            onClick = { onTabSelected(2) },
            icon = { Icon(if (activeTab == 2) Icons.Filled.GpsFixed else Icons.Outlined.GpsFixed, contentDescription = "追蹤") },
            label = { Text("衛星追蹤", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            )
        )
        NavigationBarItem(
            selected = activeTab == 3,
            onClick = { onTabSelected(3) },
            icon = { Icon(if (activeTab == 3) Icons.Filled.Analytics else Icons.Outlined.Analytics, contentDescription = "公民科學") },
            label = { Text("公民大數據", fontSize = 11.sp) },
            colors = NavigationBarItemDefaults.colors(
                selectedIconColor = MaterialTheme.colorScheme.primary,
                indicatorColor = MaterialTheme.colorScheme.primary.copy(alpha = 0.15f)
            )
        )
    }
}

@Composable
fun MarineNavigationRail(
    activeTab: Int,
    onTabSelected: (Int) -> Unit
) {
    NavigationRail(
        containerColor = MaterialTheme.colorScheme.surface,
        header = {
            Icon(
                imageVector = Icons.Filled.Water,
                contentDescription = "Logo",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(40.dp)
                    .padding(bottom = 12.dp)
            )
        },
        modifier = Modifier.testTag("nav_rail")
    ) {
        NavigationRailItem(
            selected = activeTab == 0,
            onClick = { onTabSelected(0) },
            icon = { Icon(if (activeTab == 0) Icons.Filled.Dashboard else Icons.Outlined.Dashboard, contentDescription = "主儀表") },
            label = { Text("控制中心") }
        )
        NavigationRailItem(
            selected = activeTab == 1,
            onClick = { onTabSelected(1) },
            icon = { Icon(if (activeTab == 1) Icons.Filled.MenuBook else Icons.Outlined.MenuBook, contentDescription = "圖鑑") },
            label = { Text("軟骨魚圖鑑") }
        )
        NavigationRailItem(
            selected = activeTab == 2,
            onClick = { onTabSelected(2) },
            icon = { Icon(if (activeTab == 2) Icons.Filled.GpsFixed else Icons.Outlined.GpsFixed, contentDescription = "追蹤") },
            label = { Text("衛星追蹤") }
        )
        NavigationRailItem(
            selected = activeTab == 3,
            onClick = { onTabSelected(3) },
            icon = { Icon(if (activeTab == 3) Icons.Filled.Analytics else Icons.Outlined.Analytics, contentDescription = "公民科學") },
            label = { Text("公民大數據") }
        )
    }
}


// --- 1. 控制中心 Dashboard tab ---
@Composable
fun DashboardScreen(viewModel: MarineViewModel) {
    val speed by viewModel.kuroshioSpeed.collectAsStateWithLifecycle()
    val temp by viewModel.kuroshioTemp.collectAsStateWithLifecycle()
    val health by viewModel.ecoIndex.collectAsStateWithLifecycle()
    val reports by viewModel.citizenReports.collectAsStateWithLifecycle()

    val scrollState = rememberScrollState()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(scrollState)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 頂級大標題
        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(
                    text = "黑潮海洋研究中心",
                    fontSize = 24.sp,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.primary
                )
                Text(
                    text = "KUROSHIO MARINE TELEMETRY DECK",
                    fontSize = 11.sp,
                    fontWeight = FontWeight.Light,
                    color = Color(0xFF00FFCC),
                    letterSpacing = 1.5.sp
                )
            }
            
            // 系統在線信號
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(6.dp),
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(Color(0xFF00FFCC).copy(alpha = 0.15f))
                    .padding(horizontal = 8.dp, vertical = 4.dp)
            ) {
                Box(
                    modifier = Modifier
                        .size(8.dp)
                        .clip(CircleShape)
                        .background(Color(0xFF1DD1A1))
                )
                Text("遙測在線 ONLINE", fontSize = 10.sp, color = Color(0xFF1DD1A1), fontWeight = FontWeight.Bold)
            }
        }

        // --- 核心組件：超可愛思想泡泡 (圖鑑 1、2、3 三個角色在船上滑槳) ---
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f)),
            border = BorderStroke(1.dp, Color(0xFF00FFCC).copy(alpha = 0.25f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                // 自製卡通划船 Canvas 圖案
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .drawBehind {
                            val w = size.width
                            val h = size.height
                            // 畫一隻可愛的棕色船
                            val boatPath = Path().apply {
                                moveTo(w * 0.1f, h * 0.55f)
                                cubicTo(w * 0.15f, h * 0.85f, w * 0.85f, h * 0.85f, w * 0.9f, h * 0.55f)
                                lineTo(w * 0.85f, h * 0.55f)
                                quadraticTo(w * 0.5f, h * 0.62f, w * 0.15f, h * 0.55f)
                                close()
                            }
                            drawPath(boatPath, Color(0xFF8B5A2B))
                            
                            // 划槳
                            drawLine(Color(0xFFCD853F), Offset(w * 0.3f, h * 0.5f), Offset(w * 0.05f, h * 0.8f), strokeWidth = 5f)
                            drawLine(Color(0xFFCD853F), Offset(w * 0.7f, h * 0.5f), Offset(w * 0.95f, h * 0.8f), strokeWidth = 5f)

                            // 船上的三個小動物簡單頭像 (白貓, 粉兔, 貓咪)
                            drawCircle(Color.White, 12f, Offset(w * 0.35f, h * 0.45f)) // 貓 1
                            drawCircle(Color(0xFFFFD2D2), 11f, Offset(w * 0.50f, h * 0.42f)) // 兔 2
                            drawCircle(Color(0xFFECEFF1), 12f, Offset(w * 0.65f, h * 0.45f)) // 貓 3
                            
                            // 兔子耳朵
                            drawOval(Color(0xFFFFD2D2), Offset(w * 0.46f, h * 0.22f), Size(6f, 15f))
                            drawOval(Color(0xFFFFD2D2), Offset(w * 0.52f, h * 0.22f), Size(6f, 15f))

                            // 三個動物小微笑/表情
                            drawCircle(Color(0xFF2C3E50), 1.5f, Offset(w * 0.33f, h * 0.43f))
                            drawCircle(Color(0xFF2C3E50), 1.5f, Offset(w * 0.37f, h * 0.43f))
                            drawCircle(Color(0xFF2C3E50), 1.5f, Offset(w * 0.48f, h * 0.40f))
                            drawCircle(Color(0xFF2C3E50), 1.5f, Offset(w * 0.52f, h * 0.40f))
                        }
                )

                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "黑潮共同守護者計畫 🐳",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )
                    Spacer(modifier = Modifier.height(3.dp))
                    Text(
                        text = "「臺灣軟骨魚數位圖鑑」、「海洋巨型巨獸追蹤」與「大數據公民平台」三合一智聯網，邀請公民科學家在雷達機艙，一同探尋汪洋深處的奧秘！",
                        fontSize = 12.sp,
                        color = Color.White.copy(alpha = 0.8f),
                        lineHeight = 17.sp
                    )
                }
            }
        }

        // --- 黑潮大數據即時監測儀表 (3 個圓形/方塊傳感器) ---
        Text(
            text = "即時黑潮暖流遙測監控",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFFFECA57),
            letterSpacing = 1.sp
        )

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            // 傳感器 1: 黑潮主流速
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(115.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, Color(0xFF1B4965))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("Kuroshio 流速", fontSize = 11.sp, color = TextMuted)
                        Icon(Icons.Filled.Waves, contentDescription = "流速", tint = Color(0xFF00FFCC), modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "$speed m/s",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF00FFCC),
                        fontFamily = FontFamily.Monospace
                    )
                    Text("流向: 宜蘭東北北", fontSize = 10.sp, color = TextMuted)
                }
            }

            // 傳感器 2: 表面海溫
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(115.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, Color(0xFF1B4965))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("海表表面水溫", fontSize = 11.sp, color = TextMuted)
                        Icon(Icons.Filled.Thermostat, contentDescription = "水溫", tint = Color(0xFFFF6B6B), modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "$temp °C",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFFFF6B6B),
                        fontFamily = FontFamily.Monospace
                    )
                    Text("高於近十年平均值", fontSize = 10.sp, color = TextMuted)
                }
            }

            // 傳感器 3: 生態豐富健康度
            Card(
                modifier = Modifier
                    .weight(1f)
                    .height(115.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)),
                border = BorderStroke(1.dp, Color(0xFF1B4965))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(12.dp),
                    verticalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("生態豐富指數", fontSize = 11.sp, color = TextMuted)
                        Icon(Icons.Filled.Favorite, contentDescription = "健康度", tint = Color(0xFF1DD1A1), modifier = Modifier.size(16.dp))
                    }
                    Text(
                        text = "$health%",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.ExtraBold,
                        color = Color(0xFF1DD1A1),
                        fontFamily = FontFamily.Monospace
                    )
                    Text(
                        text = if (health > 80) "系統評定: 極佳" else "系統評定: 穩定",
                        fontSize = 10.sp,
                        color = TextMuted
                    )
                }
            }
        }

        // --- 快捷工作模塊切換板 ---
        Text(
            text = "三大核心保育系統入口",
            fontSize = 14.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White
        )

        // 入口 1: 臺灣軟骨魚類數位圖鑑與研究庫
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.selectTab(1) }
                .testTag("shortcut_to_guide"),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.15f)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(Color(0xFF00F0FF).copy(alpha = 0.1f), CircleShape)
                        .padding(8.dp)
                ) {
                    MarineCreatureVector(type = "shark", color = Color(0xFF00F0FF), modifier = Modifier.fillMaxSize())
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("1. 臺灣軟骨魚類數位圖鑑與研究庫", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = IceWhite)
                    Text("點擊進入，探索鯨鯊、雙髻鮫、鬼蝠魟等多種台灣海域明星软骨鱼類，查詢瀕危狀況與科學分類。", fontSize = 11.sp, color = TextMuted)
                }
                Icon(Icons.Filled.ArrowForwardIos, contentDescription = "進入", modifier = Modifier.size(16.dp), tint = TextMuted)
            }
        }

        // 入口 2: 海洋巨型動物衛星追蹤系統
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.selectTab(2) }
                .testTag("shortcut_to_tracking"),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.15f)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(Color(0xFFFECA57).copy(alpha = 0.1f), CircleShape)
                        .padding(8.dp)
                ) {
                    MarineCreatureVector(type = "turtle", color = Color(0xFFFECA57), modifier = Modifier.fillMaxSize())
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("2. 海洋巨型動物衛星追蹤系統", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = IceWhite)
                    Text("查看鯨鯊「小華」、綠蠵龜「阿美」、大翅鯨「藍藍」衛星天線發射的即時雷達與水深、溫度軌跡。", fontSize = 11.sp, color = TextMuted)
                }
                Icon(Icons.Filled.ArrowForwardIos, contentDescription = "進入", modifier = Modifier.size(16.dp), tint = TextMuted)
            }
        }

        // 入口 3: 黑潮生態大數據與公民科學回報平台
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .clickable { viewModel.selectTab(3) }
                .testTag("shortcut_to_citizen"),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.15f)),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                Box(
                    modifier = Modifier
                        .size(54.dp)
                        .background(Color(0xFF1DD1A1).copy(alpha = 0.1f), CircleShape)
                        .padding(10.dp)
                ) {
                    Icon(Icons.Filled.Analytics, contentDescription = "回報統計", tint = Color(0xFF1DD1A1), modifier = Modifier.fillMaxSize())
                }
                Column(modifier = Modifier.weight(1f)) {
                    Text("3. 黑潮生態大數據分析與公民科學平台", fontWeight = FontWeight.Bold, fontSize = 14.sp, color = IceWhite)
                    Text("已收集到 ${reports.size} 筆社區科學家回報。點擊查看公民目擊分布，並回傳您的第一手海洋大巨獸目擊日記！", fontSize = 11.sp, color = TextMuted)
                }
                Icon(Icons.Filled.ArrowForwardIos, contentDescription = "進入", modifier = Modifier.size(16.dp), tint = TextMuted)
            }
        }
    }
}


// --- 2. 軟骨魚圖鑑 Tab ---
@Composable
fun DigitalGuideScreen(viewModel: MarineViewModel) {
    val q by viewModel.searchQuery.collectAsStateWithLifecycle()
    val fishes by viewModel.filteredFishes.collectAsStateWithLifecycle()
    val selCat by viewModel.selectedCategory.collectAsStateWithLifecycle()
    val selStat by viewModel.selectedStatus.collectAsStateWithLifecycle()

    var selectedFishDetail by remember { mutableStateOf<CartilaginousFish?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
    ) {
        Text("臺灣軟骨魚類數位圖鑑與研究庫", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
        Spacer(modifier = Modifier.height(2.dp))
        Text("TAIWAN CHONDRICHTHYES DIGITAL LIBRARY AND DATABASE", fontSize = 9.sp, color = TextMuted, letterSpacing = 1.sp)
        
        Spacer(modifier = Modifier.height(12.dp))

        // 搜尋欄
        OutlinedTextField(
            value = q,
            onValueChange = { viewModel.setSearchQuery(it) },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_fish_field"),
            placeholder = { Text("搜尋學名、中文俗名或科屬...", fontSize = 12.sp, color = TextMuted) },
            leadingIcon = { Icon(Icons.Filled.Search, contentDescription = "Search") },
            trailingIcon = {
                if (q.isNotEmpty()) {
                    IconButton(onClick = { viewModel.setSearchQuery("") }) {
                        Icon(Icons.Filled.Clear, contentDescription = "Clear")
                    }
                }
            },
            shape = RoundedCornerShape(12.dp),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors(
                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f),
                focusedBorderColor = MaterialTheme.colorScheme.primary
            )
        )

        Spacer(modifier = Modifier.height(10.dp))

        // 分類快選晶片 (Category filter)
        Row(
            modifier = Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            listOf("全部", "鯊魚", "鱝/鰩").forEach { cat ->
                FilterChip(
                    selected = selCat == cat,
                    onClick = { viewModel.setCategoryFilter(cat) },
                    label = { Text(cat, fontSize = 12.sp) }
                )
            }
            Spacer(modifier = Modifier.width(6.dp))
            VerticalDivider(modifier = Modifier.height(30.dp), color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            Spacer(modifier = Modifier.width(6.dp))
            listOf("全部", "極危/瀕危", "易危").forEach { stat ->
                FilterChip(
                    selected = selStat == stat,
                    onClick = { viewModel.setStatusFilter(stat) },
                    label = { Text(stat, fontSize = 12.sp) }
                )
            }
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (fishes.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Icon(Icons.Filled.Waves, contentDescription = "查無資料", modifier = Modifier.size(48.dp), tint = TextMuted)
                    Text("在大洋中找不到對應的軟骨魚，請重新搜尋！", fontSize = 13.sp, color = TextMuted)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                items(fishes, key = { it.id }) { fish ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { selectedFishDetail = fish }
                            .testTag("fish_card_${fish.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(14.dp)
                        ) {
                            // 動畫向量裝飾
                            Box(
                                modifier = Modifier
                                    .size(70.dp)
                                    .background(MaterialTheme.colorScheme.background.copy(alpha = 0.4f), RoundedCornerShape(12.dp))
                                    .padding(6.dp),
                                contentAlignment = Alignment.Center
                            ) {
                                MarineCreatureVector(
                                    type = fish.vectorType,
                                    modifier = Modifier.fillMaxSize(),
                                    color = if (fish.status.contains("極危") || fish.status.contains("瀕危")) Color(0xFFFF6B6B) else Color(0xFF00F0FF)
                                )
                            }

                            Column(modifier = Modifier.weight(1f)) {
                                Row(
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                                ) {
                                    Text(fish.name, fontWeight = FontWeight.Bold, fontSize = 16.sp, color = IceWhite)
                                    Text(fish.EnglishName, fontSize = 11.sp, color = TextMuted, maxLines = 1, overflow = TextOverflow.Ellipsis)
                                }
                                
                                Text(fish.scientificName, fontSize = 11.sp, color = Color(0xFF00FFCC).copy(alpha = 0.8f), fontFamily = FontFamily.Monospace)
                                
                                Spacer(modifier = Modifier.height(4.dp))
                                
                                Row(
                                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // 瀕危級別 Badges
                                    StatusBadge(status = fish.status)
                                    Text("型體: ${fish.avgSize}", fontSize = 10.sp, color = TextMuted)
                                }
                            }

                            Icon(Icons.Filled.Info, contentDescription = "詳細", modifier = Modifier.size(20.dp), tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.7f))
                        }
                    }
                }
            }
        }
    }

    // 詳細資訊 dialog
    selectedFishDetail?.let { fish ->
        Dialog(onDismissRequest = { selectedFishDetail = null }) {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 24.dp)
                    .testTag("fish_detail_dialog"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, Color(0xFF00F0FF).copy(alpha = 0.4f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .verticalScroll(rememberScrollState())
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("軟骨魚學術報告", fontSize = 11.sp, color = Color(0xFF00FFCC), letterSpacing = 2.sp, fontWeight = FontWeight.Bold)
                        IconButton(onClick = { selectedFishDetail = null }) {
                            Icon(Icons.Filled.Close, contentDescription = "Close", tint = TextMuted)
                        }
                    }

                    // 水平分隔科技線
                    HorizontalDivider(color = Color(0xFF00FFCC).copy(alpha = 0.2f))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(90.dp)
                                .background(MaterialTheme.colorScheme.background.copy(alpha = 0.8f), RoundedCornerShape(12.dp))
                                .padding(8.dp),
                            contentAlignment = Alignment.Center
                        ) {
                            MarineCreatureVector(type = fish.vectorType, modifier = Modifier.fillMaxSize())
                        }
                        
                        Column {
                            Text(fish.name, fontSize = 22.sp, fontWeight = FontWeight.Bold, color = IceWhite)
                            Text(fish.EnglishName, fontSize = 13.sp, color = TextMuted)
                            Text(fish.scientificName, fontSize = 12.sp, color = Color(0xFF00FFCC), fontFamily = FontFamily.Monospace)
                        }
                    }

                    // 數據欄
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clip(RoundedCornerShape(12.dp))
                            .background(MaterialTheme.colorScheme.background.copy(alpha = 0.6f))
                            .padding(12.dp),
                        verticalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        DetailItemRow("界屬分類", fish.classification)
                        DetailItemRow("保育狀態", fish.status)
                        DetailItemRow("平均體長", fish.avgSize)
                        DetailItemRow("主食來源", fish.diet)
                        DetailItemRow("歷史棲息", fish.habitat)
                    }

                    Column {
                        Text("物種科學描述 :", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = fish.description,
                            fontSize = 12.sp,
                            color = Color.White.copy(alpha = 0.85f),
                            lineHeight = 18.sp
                        )
                    }

                    Button(
                        onClick = { selectedFishDetail = null },
                        modifier = Modifier.fillMaxWidth().testTag("close_dialog_btn"),
                        colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
                    ) {
                        Text("確認並返回控制台")
                    }
                }
            }
        }
    }
}

@Composable
fun StatusBadge(status: String) {
    val containerColor = when {
        status.contains("極危") -> Color(0xFFFF4D4D).copy(alpha = 0.15f)
        status.contains("瀕危") -> Color(0xFFFF5252).copy(alpha = 0.12f)
        status.contains("易危") -> Color(0xFFFF9F43).copy(alpha = 0.12f)
        else -> Color(0xFF1DD1A1).copy(alpha = 0.12f)
    }
    val contentColor = when {
        status.contains("極危") -> Color(0xFFFF4D4D)
        status.contains("瀕危") -> Color(0xFFFF5252)
        status.contains("易危") -> Color(0xFFFF9F43)
        else -> Color(0xFF1DD1A1)
    }

    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(4.dp))
            .background(containerColor)
            .padding(horizontal = 6.dp, vertical = 2.dp)
    ) {
        Text(status, fontSize = 9.sp, fontWeight = FontWeight.Bold, color = contentColor)
    }
}

@Composable
fun DetailItemRow(label: String, value: String) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(label, fontSize = 11.sp, color = TextMuted)
        Text(value, fontSize = 11.sp, color = IceWhite, fontWeight = FontWeight.Medium)
    }
}


// --- 3. 衛星追蹤 Tab ---
@Composable
fun SatelliteTrackingScreen(viewModel: MarineViewModel) {
    val animals = viewModel.trackedAnimals
    val selected by viewModel.selectedAnimal.collectAsStateWithLifecycle()
    val trackIdx by viewModel.currentTrackIndex.collectAsStateWithLifecycle()
    val isSimulating by viewModel.isSimulating.collectAsStateWithLifecycle()

    var showTelemetryDialog by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 標題部
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("海洋巨型動物衛星追蹤系統", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("MARINE MEGAFAUNA REAL-TIME GPS TRACKING SERVICE", fontSize = 8.sp, color = TextMuted, letterSpacing = 1.sp)
            }
            
            IconButton(
                onClick = { showTelemetryDialog = true },
                modifier = Modifier
                    .clip(CircleShape)
                    .background(MaterialTheme.colorScheme.primary.copy(alpha = 0.1f))
            ) {
                Icon(Icons.Filled.AddLocation, contentDescription = "新增自主航點", tint = MaterialTheme.colorScheme.primary)
            }
        }

        // 動物切換面板
        ScrollableTabRow(
            selectedTabIndex = animals.indexOfFirst { it.id == selected?.id }.coerceAtLeast(0),
            containerColor = Color.Transparent,
            edgePadding = 0.dp,
            divider = {},
            indicator = {}
        ) {
            animals.forEach { animal ->
                val isSel = selected?.id == animal.id
                Tab(
                    selected = isSel,
                    onClick = { viewModel.selectAnimal(animal) },
                    modifier = Modifier.padding(horizontal = 4.dp),
                    text = {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier
                                .clip(RoundedCornerShape(30.dp))
                                .background(if (isSel) MaterialTheme.colorScheme.primary.copy(alpha = 0.2f) else MaterialTheme.colorScheme.surface)
                                .border(1.dp, if (isSel) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f), RoundedCornerShape(30.dp))
                                .padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Box(modifier = Modifier.size(24.dp)) {
                                MarineCreatureVector(
                                    type = animal.iconType,
                                    color = if (isSel) MaterialTheme.colorScheme.primary else TextMuted
                                )
                            }
                            Text(
                                text = animal.name,
                                fontSize = 12.sp,
                                fontWeight = if (isSel) FontWeight.Bold else FontWeight.Normal,
                                color = if (isSel) IceWhite else TextMuted
                            )
                        }
                    }
                )
            }
        }

        // 主電視遙測網格畫布 (Telemetry Map)
        selected?.let { animal ->
            val points = animal.trackingPoints
            val currentPoint = points.getOrNull(trackIdx)

            // 連接與渲染自製的地圖 Custom Canvas
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(16.dp))
                    .border(1.dp, Color(0xFF00FFCC).copy(alpha = 0.3f), RoundedCornerShape(16.dp))
            ) {
                KuroshioTelemetryMap(
                    points = points,
                    currentIndex = trackIdx,
                    isSimulating = isSimulating,
                    modifier = Modifier.fillMaxSize(),
                    onPointSelected = { viewModel.setTrackIndex(it) }
                )

                // 浮動儀表板資訊 (Float Overlay)
                currentPoint?.let { pt ->
                    Card(
                        modifier = Modifier
                            .align(Alignment.BottomStart)
                            .padding(12.dp)
                            .widthIn(max = 240.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.85f)),
                        border = BorderStroke(1.dp, Color(0xFFFF9F43).copy(alpha = 0.4f)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Column(
                            modifier = Modifier.padding(10.dp),
                            verticalArrangement = Arrangement.spacedBy(4.dp)
                        ) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = if (pt.label.isNotEmpty()) pt.label else "雷達定位第 ${trackIdx + 1} 點",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFFFF9F43)
                                )
                                Box(
                                    modifier = Modifier
                                        .size(6.dp)
                                        .clip(CircleShape)
                                        .background(Color(0xFFFECA57))
                                )
                            }
                            
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.15f))
                            
                            Text("經緯: ${String.format("%.2f", pt.latitude)}°N, ${String.format("%.2f", pt.longitude)}°E", fontSize = 11.sp, color = IceWhite, fontFamily = FontFamily.Monospace)
                            Text("水溫: ${pt.waterTempCelsius}°C | 深度: ${pt.depthMeters} m", fontSize = 10.sp, color = TextMuted)
                            Text("時速: ${String.format("%.1f", pt.speedKnots)} 節 | 剩餘電量: ${animal.batteryPercent}%", fontSize = 10.sp, color = TextMuted)
                        }
                    }
                }
            }

            // 控制器 (Play, Pause, Step)
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier.padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text("航標軌跡快搜播放軸", fontSize = 11.sp, color = TextMuted)
                        Text("${trackIdx + 1} / ${points.size} 階段", fontSize = 11.sp, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                    }

                    // 滑桿控制
                    Slider(
                        value = trackIdx.toFloat(),
                        onValueChange = { viewModel.setTrackIndex(it.toInt()) },
                        valueRange = 0f..(points.size - 1).coerceAtLeast(1).toFloat(),
                        steps = (points.size - 2).coerceAtLeast(0),
                        colors = SliderDefaults.colors(
                            thumbColor = Color(0xFFFF9F43),
                            activeTrackColor = Color(0xFFFF9F43).copy(alpha = 0.7f),
                            inactiveTrackColor = MaterialTheme.colorScheme.surfaceVariant
                        ),
                        modifier = Modifier.testTag("track_slider")
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Button(
                            onClick = {
                                if (isSimulating) viewModel.stopSimulation() else viewModel.startSimulation()
                            },
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (isSimulating) Color(0xFFFF5252) else MaterialTheme.colorScheme.primary
                            ),
                            shape = RoundedCornerShape(20.dp),
                            modifier = Modifier.testTag("play_simulation_btn")
                        ) {
                            Icon(
                                imageVector = if (isSimulating) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                                contentDescription = "Play",
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (isSimulating) "暫停模擬" else "播放洄游模擬", fontSize = 12.sp)
                        }

                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            OutlinedButton(
                                onClick = {
                                    val next = (trackIdx + 1) % points.size
                                    viewModel.setTrackIndex(next)
                                },
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            ) {
                                Text("下個航點", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = {
                                    viewModel.setTrackIndex(0)
                                    viewModel.stopSimulation()
                                },
                                shape = RoundedCornerShape(20.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            ) {
                                Text("重置", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }

    // 自主航點注入 Dialog
    if (showTelemetryDialog) {
        var inputLat by remember { mutableStateOf("22.8") }
        var inputLng by remember { mutableStateOf("121.9") }
        var inputDepth by remember { mutableStateOf("45") }
        var inputTemp by remember { mutableStateOf("26.4") }
        val context = LocalContext.current

        Dialog(onDismissRequest = { showTelemetryDialog = false }) {
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, Color(0xFF00FFCC).copy(alpha = 0.4f)),
                modifier = Modifier.testTag("add_telemetry_dialog")
            ) {
                Column(
                    modifier = Modifier.padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text("虛擬衛星航標注入器", fontSize = 16.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                    Text("向當前選取的海洋動物追加一筆高頻微波 GPS 接收定位，並更新至雷達顯示儀。", fontSize = 11.sp, color = TextMuted)
                    
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))

                    OutlinedTextField(
                        value = inputLat,
                        onValueChange = { inputLat = it },
                        label = { Text("緯度 Latitude (°N)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().testTag("lat_field")
                    )

                    OutlinedTextField(
                        value = inputLng,
                        onValueChange = { inputLng = it },
                        label = { Text("經度 Longitude (°E)", fontSize = 11.sp) },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                        modifier = Modifier.fillMaxWidth().testTag("lng_field")
                    )

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = inputDepth,
                            onValueChange = { inputDepth = it },
                            label = { Text("回傳水深 (m)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("depth_field")
                        )
                        OutlinedTextField(
                            value = inputTemp,
                            onValueChange = { inputTemp = it },
                            label = { Text("回傳水溫 (°C)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("temp_field")
                        )
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        TextButton(onClick = { showTelemetryDialog = false }) {
                            Text("取消")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = {
                                val lat = inputLat.toDoubleOrNull()
                                val lng = inputLng.toDoubleOrNull()
                                val depth = inputDepth.toDoubleOrNull()
                                val temp = inputTemp.toDoubleOrNull()
                                if (lat != null && lng != null && depth != null && temp != null) {
                                    viewModel.appendMockTrackPoint(lat, lng, depth, temp)
                                    showTelemetryDialog = false
                                    Toast.makeText(context, "衛星定軌成功！已加入軌跡中端", Toast.LENGTH_SHORT).show()
                                } else {
                                    Toast.makeText(context, "請輸入正確數字格式", Toast.LENGTH_SHORT).show()
                                }
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF00FFCC)),
                            modifier = Modifier.testTag("submit_telemetry_btn")
                        ) {
                            Text("注入定軌資料", color = Color(0xFF050B14))
                        }
                    }
                }
            }
        }
    }
}


// --- 4. 黑潮生態大數據與公民科學 Tab ---
@Composable
fun CitizenScienceScreen(viewModel: MarineViewModel) {
    val reports by viewModel.citizenReports.collectAsStateWithLifecycle()
    val syncingIds by viewModel.syncingReportIds.collectAsStateWithLifecycle()

    var showAddForm by remember { mutableStateOf(false) }

    // 表單輸入狀態
    var reporterName by remember { mutableStateOf("") }
    var selectedSpecies by remember { mutableStateOf("鯨鯊") }
    var locationName by remember { mutableStateOf("花蓮外海二浬") }
    var latInput by remember { mutableStateOf("24.02") }
    var lngInput by remember { mutableStateOf("121.68") }
    var countInput by remember { mutableStateOf("1") }
    var depthInput by remember { mutableStateOf("10.0") }
    var weatherCondition by remember { mutableStateOf("晴朗無風") }
    var notesInput by remember { mutableStateOf("") }

    val context = LocalContext.current

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // 標題
        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text("黑潮生態大數據與公民科學平台", fontSize = 18.sp, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                Text("KUROSHIO OCEANIC CITIZEN SCIENCE BIG-DATA DESK", fontSize = 8.sp, color = TextMuted, letterSpacing = 0.5.sp)
            }
            
            Button(
                onClick = { showAddForm = !showAddForm },
                shape = RoundedCornerShape(12.dp)
            ) {
                Icon(if (showAddForm) Icons.Filled.Close else Icons.Filled.Add, contentDescription = "新增目擊")
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (showAddForm) "關閉回報" else "填寫回報", fontSize = 12.sp)
            }
        }

        if (showAddForm) {
            // 回報填寫面板 Form
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("citizen_form_card")
                    .border(1.dp, Color(0xFF1DD1A1).copy(alpha = 0.3f), RoundedCornerShape(12.dp)),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(
                    modifier = Modifier
                        .verticalScroll(rememberScrollState())
                        .padding(14.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text("海洋大生物目擊日誌登錄", fontSize = 14.sp, fontWeight = FontWeight.Bold, color = Color(0xFF1DD1A1))
                    
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = reporterName,
                            onValueChange = { reporterName = it },
                            label = { Text("您的姓名", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1f).testTag("form_reporter")
                        )
                        
                        // 種類下拉選項 Mock (點擊輪流轉換)
                        val speciesList = listOf("鯨鯊", "丫髻鮫", "雙吻前口蝠鱝", "綠蠵龜", "大翅鯨", "其他珍稀軟骨魚")
                        OutlinedButton(
                            onClick = {
                                val currIdx = speciesList.indexOf(selectedSpecies)
                                selectedSpecies = speciesList[(currIdx + 1) % speciesList.size]
                            },
                            modifier = Modifier
                                .weight(1.2f)
                                .height(56.dp)
                                .padding(top = 8.dp)
                                .testTag("form_species_picker")
                        ) {
                            Text("物種: $selectedSpecies", fontSize = 11.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        }
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = locationName,
                            onValueChange = { locationName = it },
                            label = { Text("目擊地點", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1.2f).testTag("form_location")
                        )
                        OutlinedTextField(
                            value = countInput,
                            onValueChange = { countInput = it },
                            label = { Text("隻數", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                            modifier = Modifier.weight(0.8f).testTag("form_count")
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = latInput,
                            onValueChange = { latInput = it },
                            label = { Text("緯度 (°N)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("form_lat")
                        )
                        OutlinedTextField(
                            value = lngInput,
                            onValueChange = { lngInput = it },
                            label = { Text("經度 (°E)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1f).testTag("form_lng")
                        )
                    }

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = depthInput,
                            onValueChange = { depthInput = it },
                            label = { Text("預估深度 (m)", fontSize = 11.sp) },
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal),
                            modifier = Modifier.weight(1.0f).testTag("form_depth")
                        )
                        OutlinedTextField(
                            value = weatherCondition,
                            onValueChange = { weatherCondition = it },
                            label = { Text("氣候風浪", fontSize = 11.sp) },
                            singleLine = true,
                            modifier = Modifier.weight(1.0f).testTag("form_weather")
                        )
                    }

                    OutlinedTextField(
                        value = notesInput,
                        onValueChange = { notesInput = it },
                        label = { Text("目擊詳情描述或備註...", fontSize = 11.sp) },
                        maxLines = 2,
                        modifier = Modifier.fillMaxWidth().testTag("form_notes")
                    )

                    Button(
                        onClick = {
                            val lat = latInput.toDoubleOrNull() ?: 24.0
                            val lng = lngInput.toDoubleOrNull() ?: 121.6
                            val count = countInput.toIntOrNull() ?: 1
                            val depth = depthInput.toDoubleOrNull() ?: 5.0
                            if (reporterName.isNotBlank()) {
                                viewModel.submitCitizenReport(
                                    name = reporterName,
                                    species = selectedSpecies,
                                    location = locationName,
                                    lat = lat,
                                    lng = lng,
                                    count = count,
                                    depth = depth,
                                    weather = weatherCondition,
                                    notes = notesInput
                                )
                                showAddForm = false
                                Toast.makeText(context, "日誌保存至本地 SQLite 庫！", Toast.LENGTH_SHORT).show()
                                // 清空部分
                                notesInput = ""
                            } else {
                                Toast.makeText(context, "請輸入您的姓名", Toast.LENGTH_SHORT).show()
                            }
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF1DD1A1)),
                        modifier = Modifier.fillMaxWidth().testTag("form_submit_btn")
                    ) {
                        Text("送出目擊日誌", color = Color(0xFF050B14))
                    }
                }
            }
        }

        // 大數據統計圖表區 (Citizen Science Charts drawn dynamically on Canvas!)
        Card(
            modifier = Modifier.fillMaxWidth().height(110.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.15f)),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.2f))
        ) {
            Column(modifier = Modifier.padding(10.dp)) {
                Text("黑潮物種目擊公民大數據佔比 (動態統計中)", fontSize = 11.sp, color = TextMuted, fontWeight = FontWeight.Bold)
                Spacer(modifier = Modifier.height(8.dp))
                
                // 動態用 Canvas 畫比例堆疊圖
                Canvas(modifier = Modifier.fillMaxWidth().height(24.dp)) {
                    val w = size.width
                    val h = size.height
                    
                    // 各種物種的比例：鯨鯊 40%, 綠蠵龜 30%, 大翅鯨 15%, 雙髻鯊等 15%
                    val lWhaleShark = w * 0.4f
                    val lTurtle = w * 0.3f
                    val lHumpback = w * 0.15f
                    val lOthers = w * 0.15f
                    
                    drawRoundRect(Color(0xFF00F0FF), Offset(0f, 0f), Size(lWhaleShark, h), cornerRadius = CornerRadius(8f, 8f))
                    drawRect(Color(0xFF1DD1A1), Offset(lWhaleShark, 0f), Size(lTurtle, h))
                    drawRect(Color(0xFFFF9F43), Offset(lWhaleShark + lTurtle, 0f), Size(lHumpback, h))
                    drawRoundRect(Color(0xFFFF6B6B), Offset(lWhaleShark + lTurtle + lHumpback, 0f), Size(lOthers, h), cornerRadius = CornerRadius(8f, 8f))
                }
                
                Spacer(modifier = Modifier.height(6.dp))
                
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    LegendItem("鯨鯊 40%", Color(0xFF00F0FF))
                    LegendItem("綠蠵龜 30%", Color(0xFF1DD1A1))
                    LegendItem("大翅鯨 15%", Color(0xFFFF9F43))
                    LegendItem("其他 15%", Color(0xFFFF6B6B))
                }
            }
        }

        // 目擊回列表
        Text("社群公民回報歷史明細", fontSize = 13.sp, fontWeight = FontWeight.Bold, color = IceWhite)

        if (reports.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f)
                    .clip(RoundedCornerShape(12.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.1f)),
                contentAlignment = Alignment.Center
            ) {
                Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Icon(Icons.Filled.CloudOff, contentDescription = "空無一物", modifier = Modifier.size(40.dp), tint = TextMuted)
                    Text("暫無目擊報告。點擊右上角新增您的第一筆觀測！", fontSize = 12.sp, color = TextMuted)
                }
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(reports, key = { it.id }) { report ->
                    val isSyncing = syncingIds.contains(report.id)
                    val dateFormatted = remember(report.timestamp) {
                        val sdf = SimpleDateFormat("yyyy/MM/dd HH:mm", Locale.getDefault())
                        sdf.format(Date(report.timestamp))
                    }

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("report_item_${report.id}"),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                    Box(
                                        modifier = Modifier
                                            .size(8.dp)
                                            .clip(CircleShape)
                                            .background(
                                                when (report.species) {
                                                    "鯨鯊" -> Color(0xFF00F0FF)
                                                    "綠蠵龜" -> Color(0xFF1DD1A1)
                                                    "大翅鯨" -> Color(0xFFFF9F43)
                                                    else -> Color(0xFFFF6B6B)
                                                }
                                            )
                                    )
                                    Text(report.species, fontWeight = FontWeight.Bold, fontSize = 14.sp, color = IceWhite)
                                    Text("(${report.sightingCount} 隻)", fontSize = 12.sp, color = TextMuted)
                                }

                                // 是否已同步狀態 Badges
                                if (report.isSynced) {
                                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(3.dp)) {
                                        Icon(Icons.Filled.CloudDone, contentDescription = "Synced", tint = Color(0xFF1DD1A1), modifier = Modifier.size(14.dp))
                                        Text("已同步雲端庫", fontSize = 10.sp, color = Color(0xFF1DD1A1))
                                    }
                                } else {
                                    if (isSyncing) {
                                        Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                            CircularProgressIndicator(modifier = Modifier.size(10.dp), strokeWidth = 1.5.dp, color = Color(0xFF00F0FF))
                                            Text("傳輸上傳中...", fontSize = 10.sp, color = Color(0xFF00F0FF))
                                        }
                                    } else {
                                        OutlinedButton(
                                            onClick = { viewModel.syncReportWithBigDataCloud(report.id) },
                                            modifier = Modifier
                                                .height(26.dp)
                                                .testTag("sync_btn_${report.id}"),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                            border = BorderStroke(1.dp, Color(0xFFFECA57).copy(alpha = 0.6f))
                                        ) {
                                            Icon(Icons.Filled.Upload, contentDescription = "Sync", modifier = Modifier.size(10.dp), tint = Color(0xFFFECA57))
                                            Spacer(modifier = Modifier.width(3.dp))
                                            Text("同步上傳", fontSize = 9.sp, color = Color(0xFFFECA57))
                                        }
                                    }
                                }
                            }

                            Text(
                                text = "目擊點: ${report.locationName} (${String.format("%.2f", report.latitude)}°N, ${String.format("%.2f", report.longitude)}°E)",
                                fontSize = 11.sp,
                                color = TextMuted
                            )
                            
                            if (report.notes.isNotBlank()) {
                                Text(
                                    text = "備註: ${report.notes}",
                                    fontSize = 11.sp,
                                    color = Color.White.copy(alpha = 0.85f)
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "觀測人: ${report.reporterName} | 氣候: ${report.weatherCondition} | 時間: $dateFormatted",
                                    fontSize = 10.sp,
                                    color = TextMuted
                                )
                                
                                IconButton(
                                    onClick = { viewModel.deleteReport(report.id) },
                                    modifier = Modifier.size(24.dp).testTag("delete_report_btn_${report.id}")
                                ) {
                                    Icon(Icons.Outlined.Delete, contentDescription = "Delete", tint = Color(0xFFFF5252).copy(alpha = 0.8f), modifier = Modifier.size(14.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun LegendItem(label: String, color: Color) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(4.dp)
    ) {
        Box(
            modifier = Modifier
                .size(8.dp)
                .clip(CircleShape)
                .background(color)
        )
        Text(label, fontSize = 9.sp, color = TextMuted)
    }
}
