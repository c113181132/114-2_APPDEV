package com.example.data

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface ReportDao {
    @Query("SELECT * FROM citizen_reports ORDER BY timestamp DESC")
    fun getAllReports(): Flow<List<CitizenReport>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: CitizenReport)

    @Query("DELETE FROM citizen_reports WHERE id = :id")
    suspend fun deleteReportById(id: Int)

    @Query("UPDATE citizen_reports SET isSynced = :isSynced WHERE id = :id")
    suspend fun updateSyncState(id: Int, isSynced: Boolean)

    @Query("DELETE FROM citizen_reports")
    suspend fun clearAllReports()
}
