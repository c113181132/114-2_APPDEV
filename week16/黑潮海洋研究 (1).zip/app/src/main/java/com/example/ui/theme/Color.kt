package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Kuroshio Ocean Theme Colors
val DeepOceanNavy = Color(0xFF050B14)      // Dark background representing deep sea abyss
val CardDarkNavy = Color(0xFF0D1B2A)      // Darker navy for container surfaces
val KuroshioBlackStream = Color(0xFF0B2545) // Deep Kuroshio current blue-black
val NeonCyan = Color(0xFF00F0FF)            // High-tech highlight/cyan light
val OceanTeal = Color(0xFF14213d)          // Supportive dark teal
val CoralOrange = Color(0xFFFF6B6B)        // Coral active accents
val SeaTurtleGreen = Color(0xFF1DD1A1)     // Turtle track / healthy eco green
val SandYellow = Color(0xFFFECA57)         // Sandy glowing tracking dots
val IceWhite = Color(0xFFF1F2F6)           // High contrast text
val TextMuted = Color(0xFF8D99AE)           // Grey for minor texts

// Material 3 Dark theme mapping
val PrimaryDark = NeonCyan
val SecondaryDark = SeaTurtleGreen
val TertiaryDark = CoralOrange
val BackgroundDark = DeepOceanNavy
val SurfaceDark = CardDarkNavy
val OnPrimaryDark = Color(0xFF050B14)
val OnSecondaryDark = Color(0xFF050B14)
val OnBackgroundDark = IceWhite
val OnSurfaceDark = IceWhite

// Material 3 Light theme mapping
val PrimaryLight = Color(0xFF00658B)
val SecondaryLight = Color(0xFF2B6653)
val TertiaryLight = Color(0xFF904B40)
val BackgroundLight = Color(0xFFF0F5FA)
val SurfaceLight = Color(0xFFFFFFFF)
val OnPrimaryLight = Color.White
val OnSecondaryLight = Color.White
val OnBackgroundLight = Color(0xFF171C22)
val OnSurfaceLight = Color(0xFF171C22)
