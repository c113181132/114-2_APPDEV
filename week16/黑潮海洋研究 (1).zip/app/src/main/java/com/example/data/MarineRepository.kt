package com.example.data

import kotlinx.coroutines.flow.Flow
import java.util.Calendar

class MarineRepository(private val reportDao: ReportDao) {

    // 取得所有本地公民科學回報
    val allReports: Flow<List<CitizenReport>> = reportDao.getAllReports()

    // 新增公民科學回報
    suspend fun insertReport(report: CitizenReport) {
        reportDao.insertReport(report)
    }

    // 刪除公民科學回報
    suspend fun deleteReportById(id: Int) {
        reportDao.deleteReportById(id)
    }

    // 更新同步狀態
    suspend fun updateSyncState(id: Int, isSynced: Boolean) {
        reportDao.updateSyncState(id, isSynced)
    }

    // 清除所有回報
    suspend fun clearAllReports() {
        reportDao.clearAllReports()
    }

    /**
     * 靜態資料：臺灣軟骨魚類數位圖鑑
     */
    fun getCartilaginousFishes(): List<CartilaginousFish> {
        return listOf(
            CartilaginousFish(
                id = "shark_whale",
                name = "鯨鯊",
                EnglishName = "Whale Shark",
                scientificName = "Rhincodon typus",
                classification = "鬚鯊目 - 鯨鯊科",
                status = "瀕危 (EN)",
                avgSize = "10 - 15 公尺 (最大可達18公尺)",
                description = "世界上最大的魚類，性情極其溫和，主要以浮游生物、小魚小蝦及珊瑚卵為食。在台灣東部及南方海域，經常隨黑潮流動洄游，是台灣賞鯨或潛水活動的明星生物。",
                habitat = "大洋表層至中層，廣泛分佈於全球熱帶與溫帶溫暖海域。",
                diet = "濾食型：浮游生物、磷蝦、水母、魚卵、小型集群魚類。",
                vectorType = "shark_whale"
            ),
            CartilaginousFish(
                id = "hammerhead",
                name = "丫髻鮫",
                EnglishName = "Scalloped Hammerhead",
                scientificName = "Sphyrna lewini",
                classification = "真鯊目 - 雙髻鮫科",
                status = "極危 (CR)",
                avgSize = "3 - 4 公尺",
                description = "獨特的頭部橫向擴展，呈「丫字形」或雙髻狀。這種特殊的構造不僅能擴大視覺範圍與嗅覺感應力，還能提升電磁場探測器（羅倫氏腹器）的覆蓋率。台灣東部與南方海面經常有幼鯊或集群目擊紀錄。",
                habitat = "近海沿岸至大洋斜坡，常成群出沒於島嶼及礁石周邊。",
                diet = "多樣性底棲魚類、魷魚、烏賊、小型甲殼類及其他鰩科魚類。",
                vectorType = "hammerhead"
            ),
            CartilaginousFish(
                id = "manta_ray",
                name = "雙吻前口蝠鱝",
                EnglishName = "Giant Oceanic Manta Ray",
                scientificName = "Mobula birostris",
                classification = "鼇形目 - 蝠鱝科",
                status = "瀕危 (EN)",
                avgSize = "翼展幅寬 5 - 7 公尺 (最重可達2噸)",
                description = "俗名鬼蝠魟、魔鬼魚。兩側胸鰭如巨大的翅膀在海中優雅地振翅滑行，頭前有一對明顯的角狀頭鰭（頭角），用於引導食物流入口內。性情溫順，熱愛跟隨黑潮支流靠近台灣東岸礁石區進行清潔和覓食。",
                habitat = "暖水性大洋中層與表層，喜好出沒於強流之海山、礁體邊緣。",
                diet = "濾食型：主要過濾海洋表層的大量浮游甲殼類、橈足類與小軟體動物。",
                vectorType = "manta"
            ),
            CartilaginousFish(
                id = "great_white",
                name = "大白鯊",
                EnglishName = "Great White Shark",
                scientificName = "Carcharodon carcharias",
                classification = "鼠鯊目 - 鼠鯊科",
                status = "易危 (VU)",
                avgSize = "4 - 5.5 公尺",
                description = "體型龐大且兇猛的頂級海洋食肉掠食者。擁有流線型軀體、鋸齒狀尖牙與極度靈敏的溫度、震動傳感器。雖然大白鯊並非台灣常駐物種，但在春季與初夏，隨著鰹魚、鯖魚、海豚等洄游，偶爾會在蘇澳、花蓮等東部黑潮邊緣海域被捕獲或目擊。",
                habitat = "溫帶與熱帶近岸及外洋水域，常在海豹群落或大型魚群集結處活動。",
                diet = "大型硬骨魚類、其他鯊魚、海獅、海豹、海豚等海洋哺乳動物。",
                vectorType = "great_white"
            ),
            CartilaginousFish(
                id = "bowmouth_guitarfish",
                name = "波口鱟頭鱝",
                EnglishName = "Bowmouth Guitarfish",
                scientificName = "Rhina ancylostoma",
                classification = "鱟頭鱝科",
                status = "極危 (CR)",
                avgSize = "2.2 - 2.7 公尺",
                description = "俗稱飯鏟鯊、圓頭鯊。頭部寬闊肥厚、前半呈圓弧狀，背部中央與眼眶上方有一排尖銳突起的骨質棘盾。牠們是介於鯊魚與鰩魚（魟魚）之間的演化橋梁，長相怪異逗趣。分布於台灣西南部與澎湖海域。",
                habitat = "暖水域底棲型，常在碎石、珊瑚礁或沙泥質洋底活動。",
                diet = "底棲蟹類、龍蝦、蝦類、蚌類及硬骨魚類。",
                vectorType = "sawfish"
            ),
            CartilaginousFish(
                id = "eagle_ray",
                name = "納氏鷂鱝",
                EnglishName = "Spotted Eagle Ray",
                scientificName = "Aetobatus narinari",
                classification = "鱝目 - 鷂鱝科",
                status = "瀕危 (EN)",
                avgSize = "翼展幅寬 1.5 - 2.2 公尺",
                description = "背部滿佈均勻雪白的斑點，長著像鳥嘴一般的突出吻部。尾巴極長，基部有劇毒的毒刺。游泳姿態如同空中滑翔，極富觀賞價值。偏好沿著東部黑潮溫暖清澈的礁珊瑚帶穿梭覓食。",
                habitat = "熱帶與副熱帶淺海沿岸、沙洲、珊瑚礁區，偶爾跨越大洋。",
                diet = "底棲的貝類、螺類、蛤蜊、螃蟹、蠕蟲及小魚。",
                vectorType = "eagle_ray"
            )
        )
    }

    /**
     * 靜態與動態模擬資料：海洋巨型動物衛星追蹤系統
     */
    fun getTrackedAnimals(): List<TrackedAnimal> {
        val now = System.currentTimeMillis()
        val oneHourArgs = 3600 * 1000L

        return listOf(
            TrackedAnimal(
                id = "whale_shark_hua",
                name = "鯨鯊「小華」",
                species = "鯨鯊 (Rhincodon typus)",
                iconType = "shark",
                deployDate = "2026-03-12",
                batteryPercent = 84,
                trackingPoints = listOf(
                    TrackPoint(21.50, 121.80, 12.0, 27.5, 4.2, now - 48 * oneHourArgs, "巴士海峽出發點"),
                    TrackPoint(22.15, 121.65, 35.0, 26.8, 3.8, now - 36 * oneHourArgs, "蘭嶼東方海域"),
                    TrackPoint(22.95, 121.72, 8.0, 27.0, 4.5, now - 24 * oneHourArgs, "綠島東北方洋流"),
                    TrackPoint(23.70, 121.85, 95.0, 26.1, 3.5, now - 12 * oneHourArgs, "花蓮外海深海溝"),
                    TrackPoint(24.35, 122.02, 22.0, 25.8, 4.1, now, "即時追蹤位置：三貂角東南海面")
                )
            ),
            TrackedAnimal(
                id = "sea_turtle_mei",
                name = "綠蠵龜「阿美」",
                species = "綠蠵龜 (Chelonia mydas)",
                iconType = "turtle",
                deployDate = "2026-04-05",
                batteryPercent = 92,
                trackingPoints = listOf(
                    TrackPoint(22.02, 120.35, 3.0, 28.5, 1.2, now - 36 * oneHourArgs, "小琉球保護區"),
                    TrackPoint(21.90, 120.55, 6.0, 28.2, 1.8, now - 24 * oneHourArgs, "鵝鑾鼻海灘繞行"),
                    TrackPoint(21.78, 120.85, 15.0, 27.9, 2.0, now - 12 * oneHourArgs, "進入七星岩海流"),
                    TrackPoint(22.10, 121.12, 4.0, 27.5, 1.5, now, "即時追蹤位置：蘭嶼南側潮池礁區")
                )
            ),
            TrackedAnimal(
                id = "humpback_lan",
                name = "大翅鯨「藍藍」",
                species = "大翅鯨 (Megaptera novaeangliae)",
                iconType = "whale",
                deployDate = "2026-01-20",
                batteryPercent = 71,
                trackingPoints = listOf(
                    TrackPoint(20.50, 121.20, 150.0, 25.2, 7.2, now - 30 * oneHourArgs, "菲律賓群島北方"),
                    TrackPoint(22.20, 121.90, 45.0, 24.5, 6.8, now - 20 * oneHourArgs, "綠島外大洋深水區"),
                    TrackPoint(24.05, 122.45, 210.0, 23.8, 6.5, now - 10 * oneHourArgs, "與那國島西側"),
                    TrackPoint(25.30, 122.90, 80.0, 22.5, 6.0, now, "即時追蹤位置：釣魚台群島海域 (向北遷徙中)")
                )
            )
        )
    }
}
