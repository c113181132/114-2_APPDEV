package com.example.viewmodel

import androidx.lifecycle.ViewModel
import androidx.lifecycle.ViewModelProvider
import androidx.lifecycle.viewModelScope
import com.example.data.*
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

class MarineViewModel(private val repository: MarineRepository) : ViewModel() {

    // --- Tab / Navigation State ---
    private val _activeTab = MutableStateFlow(0) // 0: Dashboard, 1: Guide, 2: Tracking, 3: Citizen Science
    val activeTab: StateFlow<Int> = _activeTab.asStateFlow()

    fun selectTab(tab: Int) {
        _activeTab.value = tab
    }

    // --- 1. 臺灣軟骨魚類數位圖鑑狀態 ---
    val allFishes: List<CartilaginousFish> = repository.getCartilaginousFishes()

    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    private val _selectedCategory = MutableStateFlow("全部") // 全部, 鯊魚, 鱝/鰩
    val selectedCategory: StateFlow<String> = _selectedCategory.asStateFlow()

    private val _selectedStatus = MutableStateFlow("全部") // 全部, 極危/瀕危, 易危
    val selectedStatus: StateFlow<String> = _selectedStatus.asStateFlow()

    val filteredFishes: StateFlow<List<CartilaginousFish>> = combine(
        _searchQuery, _selectedCategory, _selectedStatus
    ) { query, category, status ->
        allFishes.filter { fish ->
            val matchQuery = fish.name.contains(query, ignoreCase = true) ||
                    fish.EnglishName.contains(query, ignoreCase = true) ||
                    fish.scientificName.contains(query, ignoreCase = true)
            
            val matchCategory = when (category) {
                "鯊魚" -> fish.classification.contains("鯊") || fish.vectorType.contains("shark") || fish.name.contains("鮫") || fish.name.contains("鯊")
                "鱝/鰩" -> fish.classification.contains("鱝") || fish.classification.contains("鰩") || fish.classification.contains("目") && !fish.classification.contains("鯊") || fish.vectorType.contains("manta") || fish.vectorType.contains("ray")
                else -> true
            }

            val matchStatus = when (status) {
                "極危/瀕危" -> fish.status.contains("極危") || fish.status.contains("瀕危")
                "易危" -> fish.status.contains("易危")
                else -> true
            }

            matchQuery && matchCategory && matchStatus
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), allFishes)

    fun setSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun setCategoryFilter(category: String) {
        _selectedCategory.value = category
    }

    fun setStatusFilter(status: String) {
        _selectedStatus.value = status
    }


    // --- 2. 海洋巨型動物衛星追蹤系統狀態 ---
    val trackedAnimals: List<TrackedAnimal> = repository.getTrackedAnimals()

    private val _selectedAnimal = MutableStateFlow<TrackedAnimal?>(trackedAnimals.firstOrNull())
    val selectedAnimal: StateFlow<TrackedAnimal?> = _selectedAnimal.asStateFlow()

    // 模擬當前追蹤的軌跡點索引
    private val _currentTrackIndex = MutableStateFlow(0)
    val currentTrackIndex: StateFlow<Int> = _currentTrackIndex.asStateFlow()

    private val _isSimulating = MutableStateFlow(false)
    val isSimulating: StateFlow<Boolean> = _isSimulating.asStateFlow()

    private var simulationJob: Job? = null

    fun selectAnimal(animal: TrackedAnimal) {
        _selectedAnimal.value = animal
        _currentTrackIndex.value = animal.trackingPoints.size - 1 // 預設指到最新位置
        stopSimulation()
    }

    fun setTrackIndex(index: Int) {
        val animal = _selectedAnimal.value ?: return
        if (index in animal.trackingPoints.indices) {
            _currentTrackIndex.value = index
        }
    }

    fun startSimulation() {
        if (_isSimulating.value) return
        _isSimulating.value = true
        simulationJob = viewModelScope.launch {
            while (_isSimulating.value) {
                val animal = _selectedAnimal.value ?: break
                val size = animal.trackingPoints.size
                if (size > 0) {
                    val nextIndex = (_currentTrackIndex.value + 1) % size
                    _currentTrackIndex.value = nextIndex
                }
                delay(3000) // 每3秒更新一次GPS座標模擬移動
            }
        }
    }

    fun stopSimulation() {
        _isSimulating.value = false
        simulationJob?.cancel()
        simulationJob = null
    }

    // 民眾自行新增衛星航點(虛擬，保存在隨選物件中)
    fun appendMockTrackPoint(lat: Double, lng: Double, depth: Double, temp: Double) {
        val animal = _selectedAnimal.value ?: return
        val updatedPoints = animal.trackingPoints.toMutableList()
        val newPoint = TrackPoint(
            latitude = lat,
            longitude = lng,
            depthMeters = depth,
            waterTempCelsius = temp,
            speedKnots = 3.5 + Math.random() * 2,
            timestamp = System.currentTimeMillis(),
            label = "使用者模擬回傳點"
        )
        updatedPoints.add(newPoint)
        val updatedAnimal = animal.copy(trackingPoints = updatedPoints)
        _selectedAnimal.value = updatedAnimal
        _currentTrackIndex.value = updatedPoints.size - 1
    }


    // --- 3. 黑潮生態大數據與公民科學平台狀態 ---
    val citizenReports: StateFlow<List<CitizenReport>> = repository.allReports
        .stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // 模擬同步中狀態，給予超精美的轉盤回饋
    private val _syncingReportIds = MutableStateFlow<Set<Int>>(emptySet())
    val syncingReportIds: StateFlow<Set<Int>> = _syncingReportIds.asStateFlow()

    fun submitCitizenReport(
        name: String,
        species: String,
        location: String,
        lat: Double,
        lng: Double,
        count: Int,
        depth: Double,
        weather: String,
        notes: String
    ) {
        viewModelScope.launch {
            val report = CitizenReport(
                reporterName = name,
                species = species,
                locationName = location,
                latitude = lat,
                longitude = lng,
                sightingCount = count,
                estimatedDepth = depth,
                weatherCondition = weather,
                notes = notes,
                timestamp = System.currentTimeMillis(),
                isSynced = false
            )
            repository.insertReport(report)
        }
    }

    fun deleteReport(id: Int) {
        viewModelScope.launch {
            repository.deleteReportById(id)
        }
    }

    fun syncReportWithBigDataCloud(id: Int) {
        viewModelScope.launch {
            if (_syncingReportIds.value.contains(id)) return@launch
            _syncingReportIds.update { it + id }
            
            // 模擬上傳黑潮雲端數據中心，增加高科技儀表感！
            delay(1800)
            
            repository.updateSyncState(id, isSynced = true)
            _syncingReportIds.update { it - id }
        }
    }


    // --- 4. 儀表大數據模擬遙測資訊 ---
    // 流速 (m/s)
    val kuroshioSpeed: StateFlow<Double> = flow {
        while (true) {
            val base = 1.35
            val sinWave = Math.sin(System.currentTimeMillis() / 15000.0) * 0.25
            emit(Math.round((base + sinWave) * 100).toDouble() / 100.0)
            delay(2000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1.45)

    // 水溫 (Celsius)
    val kuroshioTemp: StateFlow<Double> = flow {
        while (true) {
            val base = 26.8
            val cosWave = Math.cos(System.currentTimeMillis() / 20000.0) * 0.4
            emit(Math.round((base + cosWave) * 10).toDouble() / 10.0)
            delay(2000)
        }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 26.8)

    // 生態健康度 / 觀測指數
    val ecoIndex: StateFlow<Int> = citizenReports.map { list ->
        // 隨回報數增加而微微升高的生態豐富指標
        Math.min(98, 72 + list.size * 2)
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 72)


    override fun onCleared() {
        super.onCleared()
        stopSimulation()
    }
}

/**
 * Factory class for ViewModel constructor injection
 */
class MarineViewModelFactory(private val repository: MarineRepository) : ViewModelProvider.Factory {
    override fun <T : ViewModel> create(modelClass: Class<T>): T {
        if (modelClass.isAssignableFrom(MarineViewModel::class.java)) {
            @Suppress("UNCHECKED_CAST")
            return MarineViewModel(repository) as T
        }
        throw IllegalArgumentException("Unknown ViewModel class")
    }
}
