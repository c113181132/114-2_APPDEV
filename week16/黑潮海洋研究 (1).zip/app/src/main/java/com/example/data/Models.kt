package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * 臺灣軟骨魚類數位圖鑑與研究庫資料模型
 */
data class CartilaginousFish(
    val id: String,
    val name: String,
    val EnglishName: String,
    val scientificName: String,
    val classification: String,
    val status: String, // 國際保育等級 (Endangered, Vulnerable, Not Threatened)
    val avgSize: String,
    val description: String,
    val habitat: String,
    val diet: String,
    val vectorType: String // "shark_whale", "hammerhead", "manta", "great_white", "sawfish", "eagle_ray"
)

/**
 * 海洋巨型動物衛星追蹤系統軌跡點資料模型
 */
data class TrackPoint(
    val latitude: Double,
    val longitude: Double,
    val depthMeters: Double,
    val waterTempCelsius: Double,
    val speedKnots: Double,
    val timestamp: Long,
    val label: String = ""
)

/**
 * 被衛星追蹤之海洋巨型生物
 */
data class TrackedAnimal(
    val id: String,
    val name: String,
    val species: String,
    val iconType: String, // "turtle", "whale", "shark"
    val deployDate: String,
    val batteryPercent: Int,
    val trackingPoints: List<TrackPoint>
)

/**
 * 黑潮生態大數據與公民科學平台 - 民眾回報實體表 (Room Database Entity)
 */
@Entity(tableName = "citizen_reports")
data class CitizenReport(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val reporterName: String,
    val species: String,
    val locationName: String,
    val latitude: Double,
    val longitude: Double,
    val sightingCount: Int,
    val estimatedDepth: Double,
    val weatherCondition: String,
    val notes: String,
    val timestamp: Long = System.currentTimeMillis(),
    val isSynced: Boolean = false // 是否同步到黑潮雲端大數據庫
)
